from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC



def setUp(URL):
 global driver
 driver=webdriver.Chrome()
 driver.get(URL)
 driver.maximize_window()
 print("Opening UI")
 WebDriverWait(driver, 50).until(EC.presence_of_element_located((By.TAG_NAME, "h1")))

def tearDown():
 print("closing driver")
 driver.quit()


def test_search(item,ttlname):
 print("Clicking on search button")
 driver.find_element(By.XPATH,"/html/body/header/div/div/div[3]/button").click()
 driver.find_element(By.XPATH,"/html/body/div[2]/div/div[1]/div[2]/input").send_keys(item)
 WebDriverWait(driver, 50).until(EC.visibility_of_element_located((By.XPATH,"/html/body/div[2]/div/div[2]/div/a[2]")))
 driver.find_element(By.XPATH,"/html/body/div[2]/div/div[2]/div/a[2]").click()
 ttl = driver.title
 print("Checking page tittle is correct")
 if ttl == ttlname:
 print("Assertion successfull, page title is " + ttl)
 else:
 raise AssertionError("error")


def test_about(ttlname):
 print("Clicking on about button")
 driver.find_element(By.XPATH,"/html/body/div/div/aside/div/ul/li[1]/ul/li/div/a").click()
 ttl = driver.title
 print("Checking page tittle is correct")
 if ttl == ttlname:
 print("Assertion successfull, page title is " + ttl)
 else:
 raise AssertionError("error")