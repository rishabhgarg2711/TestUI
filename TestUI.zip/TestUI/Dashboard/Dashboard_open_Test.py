from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def setUp(URL):
 global driver
 driver=webdriver.Chrome()
 driver.get(URL)
 driver.maximize_window()
 print("Opening UI")
 WebDriverWait(driver, 50).until(EC.presence_of_element_located((By.TAG_NAME, "h1")))

def tearDown():
 print("closing driver")
 driver.quit()

def test_Title(name):
 ttl=driver.title
 print("Checking page tittle is correct")
 if ttl==name:
 print("Assertion successfull, page title is "+ttl)
 else:
 raise AssertionError("error")

def test_link(name):
 WebDriverWait(driver, 50).until(EC.presence_of_element_located((By.TAG_NAME, "a")))
 driver.find_element(By.XPATH,"//*[@id='root']/div/main/div/div/div[1]/div/div[2]/a").click()
 driver.switch_to.window(driver.window_handles[1])
 ttl = driver.title
 print("Checking page tittle is correct")
 if ttl == name:
 print("Assertion successfull, page title is " + ttl)
 else:
 raise AssertionError("error")
 # driver.switch_to.window(driver.window_handles[0])


