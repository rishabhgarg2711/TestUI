Install robotframework and selenium before running
pip install selenium
pip install robotframework

Add new external tool to run robot file in pycharm
1. Goto setting>tools>external tools
2.Click + icon
3. Give name, program name will be full path of robot.bat file(There is robot.txt change it to robot.bat)
4. Arguments= $FileName$
5. Working directory- Full path of Robot folder
6. Click Create

To run robot file
1. Right click robot file
2. External files>"name of tool which you ave in previous steps"